<?php
return array(
'pc_version' => 'V9.6.0',	//phpcms 版本号
'pc_release' => '20151225',	//phpcms 更新日期
);
?>