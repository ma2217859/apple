<?php
$LANG['the_site_not_release'] = '该站点无发布点';
$LANG['release_point_connect_failure'] = '节点『 {name} 』连接失败';
$LANG['peed_your_server'] = '同步速度视您的服务器，连接到发布点的速度而定。';
$LANG['are_release_ing'] = '正在同步中...';
$LANG['done'] = '[已完成]';
$LANG['sync_agin'] = '再次同步';
$LANG['site'] = '站点';
$LANG['path'] = '路径';
$LANG['time'] = '时间';
$LANG['upload'] = '上传';
$LANG['success'] = '成功';
$LANG['failure'] = '失败';
$LANG['not_upload'] = '没有上传';
$LANG['remind'] = '提醒';
$LANG['remind_message'] = '当删除文件的时候，如果一直无法执行成功，很可能服务器上没有该文件，请删除这条命令。';